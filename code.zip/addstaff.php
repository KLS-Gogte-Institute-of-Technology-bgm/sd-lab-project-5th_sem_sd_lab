<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        padding:10px;
       
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        padding: 10px;
        
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>         
                      <li><a href="addstaff.php">Register Staff</a></li>
                      <li><a href="addstud.php">Register Student</a></li>
                      <li><a href="addbooks.php">Add Books</a></li>
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
    <center>
      <h1 style="color:black;">Staff Registration Form</h1>
      <form method="post" action="" enctype="multipart/form-data">
        <table>
          <tr>
            <th>Enter Staff ID</th>
            <td><input style="border-radius:15px;" type="text" name="staff_id"></td>
          </tr>
           <tr>
            <th> Name</th>
            <td><input style="border-radius:15px;" type="text" name="staffname" pattern="^[A-Za-z]+$"></td>
          </tr>
           <tr>
            <th> Address</th>
            <td><input style="border-radius:15px;" type="text" name="addr"></td>
          </tr>
           <tr>
            <th> Contact</th>
            <td><input style="border-radius:15px;" type="text" name="contact" pattern="^\d{10}$"></td>
          </tr>
           <tr>
            <th> Department</th>
            <td><input style="border-radius:15px;" type="text" name="dept" pattern="^[A-Za-z]$"></td>
          </tr>
           
           <tr>
            <th> Password</th>
            <td><input style="border-radius:15px;" type="password" name="pass"></td>
          </tr>

          <tr>
            <th> Add Photo</th>
            <td><input style="border-radius:15px;" type="file" name="fileToUpload"></td>
          </tr>
        </table>
        <br>
        <input style=" background-color: #0000FF; width: 150px;height: 40px; border-radius:30px; color:white;" type="submit" name="submit" value="Register">
      </form>
    </center>
    </div>

    <?php 
      include "connect.php";
      if(isset($_POST['submit']))
      {
        $staff_id=$_POST['staff_id'];
        $staffname=$_POST['staffname'];
        $addr=$_POST['addr'];
        $contact=$_POST['contact'];
        $dept=$_POST['dept'];       
        $pass=$_POST['pass'];
        $dbfilename='';

        include 'connect.php';
  $target_dir = "upload/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
var_dump($target_file);
echo "imageFileType ".$imageFileType;
 //Check if image file is a actual image or fake image
if(isset($_POST['submit'])){

$check = filesize($_FILES["fileToUpload"]["tmp_name"]);
     if($check !== false) {
          //echo "File is not an image - " . $check["mime"] . ".";
          //echo "<script type='text/javascript'>alert('File is not an image - " . $check["mime"] . "');
    //</script>";
          $uploadOk = 1;
      } else {
          echo "File is an image.";
          $uploadOk = 0;
      }
  }
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
                $dbfilename=$target_dir .basename($_FILES["fileToUpload"]["name"]);

    } else {
        echo "Sorry, there was an error uploading your file.".mysqli_error($conn);
    }
}

  





        $query="insert into staff values('$staff_id','$staffname','$addr','$contact','$dept','$pass','$dbfilename')";
        $result=mysqli_query($conn,$query);
        if(!$result)
        {
         
          echo "<script type='text/javascript'>
          alert('Insertion Failed');
          </script>";
          die(mysqli_error($conn));
        }
        else
        {
          echo "<script type='text/javascript'>
                  </script>";
        }

      }


     ?>
</body>
</html>