<?php 
include "connect.php";
$staff_id=$_GET['staffid'];
$query="DELETE from staff where staff_id='$staff_id' ";
$result=mysqli_query($conn,$query);
if(!$result)
{
  echo "<script type='text/javascript'>
  alert('deletion failed');
  </script>";
}
else
{
  echo "<script type='text/javascript'>
  alert('Record deleted');
  window.location=('adminviewstaff.php');
  </script>";
}



 ?>