<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        
        text-align: center;
        padding: 20px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       
       }
       th
       {
        text-align: center;
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>          
                      <li><a href="addstaff.php">Register Staff</a></li>
                      <li><a href="addstud.php">Register Student</a></li>
                      
                       <li><a href="addbooks.php">Add Books</a></li>
                       <li><a href="adminview.php">View</a></li>
                       <li><a href="adminissue.php">Issue</a></li>
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
    <center>
      <h1 style="color:black;">Upload Question Papers</h1>
      <form method="post" action="" enctype="multipart/form-data">
        <table>
          <tr>
            <td>Department</td>
            <td><input type="text" name="dept"></td>
          </tr>
          <tr>  
            <td>Semester</td>
            <td><input type="text" name="sem"></td>
          </tr>
          <tr>
            <td>Subject</td>
            <td><input type="text" name="sub"></td>
          </tr>
          <tr>
            <td>Exam year</td>
            <td><input type="text" name="examyr"></td>
          </tr>
          <tr>
            <td>Upload QP</td>
            <td><input type="file" name="fileToUpload"></td>
          </tr>
        </table>
        <input type="submit" name="submit" value="Upload">
        


      </form>
    </center>
    </div>

<?php
include "connect.php";
if(isset($_POST['submit']))
{
  
  $dept=$_POST['dept'];
  $sem=$_POST['sem'];
  $sub=$_POST['sub']; 
  $examyr=$_POST['examyr']; 
  $dbfilename='';
  //$dbfilename1='';
  include 'connect.php';
  $target_dir = "upload/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
var_dump($target_file);
echo "imageFileType ".$imageFileType;
 //Check if image file is a actual image or fake image
if(isset($_POST['submit'])){

$check = filesize($_FILES["fileToUpload"]["tmp_name"]);
     if($check !== false) {
          //echo "File is not an image - " . $check["mime"] . ".";
          //echo "<script type='text/javascript'>alert('File is not an image - " . $check["mime"] . "');
    //</script>";
          $uploadOk = 1;
      } else {
          echo "File is an image.";
          $uploadOk = 0;
      }
  }
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 50000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "pdf" ) {
    echo "Sorry, only PDF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
                $dbfilename=$target_dir .basename($_FILES["fileToUpload"]["name"]);

    } else {
        echo "Sorry, there was an error uploading your file.".mysqli_error($conn);
    }
}

$query="INSERT INTO  questionpaper values('0','$dept','$sem','$sub','$examyr','$dbfilename')";
$row=mysqli_query($conn,$query);
  if(!$row){
    echo "<script type='text/javascript'>alert('Insert Failed'); </script>";
  } else { 
   // $_SESSION['Adhaar']=$Adhaar;
    echo "<script type='text/javascript'>alert('Added Successfully') 
   </script>";
  }

  

    
  
}

?>
</body>
</html>