<?php 
  session_start();
  $usn=$_SESSION['usn'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
    <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        
    }
    
       td   
       {
        
        padding: 20px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        padding: 20px;
        text-align: center;
       }
       #middle
       {
        margin-top:120px;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="studentindex.php">Home</a></li>               
                        <li><a href="studentprofile.php">Profile</a></li>
                        <li><a href="studviewbooks.php">View Books</a></li>
                        <li><a href="studviewissue.php">View Borrow Books</a></li>
                        <li><a href="index.html">Logout</a></li>
                                             
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
   <center>
        <h1 style="color:black;">Books Details</h1>
    <table >
      <tr>
      <th>Book Id</th>
      <th>Book Title</th>
      <th>Author</th>
      <th>Publication</th>
      <th>Department</th>
      <th>Quantity</th>
      </tr>
      <tr>
        <?php 

        include "connect.php";
        $q1="select * from books";
        $rs1=mysqli_query($conn,$q1);
        while($row=mysqli_fetch_assoc($rs1))
        {
          ?>
          <td><?php echo $row['book_id']; ?></td>
          <td><?php echo $row['book_title']; ?></td>
          <td><?php echo $row['author']; ?></td>
          <td><?php echo $row['publication']; ?></td>
          <td><?php echo $row['dept']; ?></td>
          <td><?php echo $row['qty']; ?></td>
          

       <?php }


         ?>
      </tr>
      
    </table>
    </center>
  </div>

</body>
</html>