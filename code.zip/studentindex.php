<?php 
  session_start();
  $usn=$_SESSION['usn'];
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        
        text-align: center;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        text-align: center;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="studentindex.php">Home</a></li>               
                        <li><a href="studentprofile.php">Profile</a></li>
                        <li><a href="studviewbooks.php">View Books</a></li>
                        <li><a href="studviewissue.php">View Borrow Books</a></li>
                        <li><a href="studentviewqp.php">View Question Papers</a></li>
                        <li><a href="index.html">Logout</a></li>
                                             
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <center>
       



</body>
</html>