<?php 
include "connect.php";
$usn=$_GET['usn'];
$query="DELETE from student where USN='$usn' ";
$result=mysqli_query($conn,$query);
if(!$result)
{
  echo "<script type='text/javascript'>
  alert('deletion failed');
  </script>";
}
else
{
  echo "<script type='text/javascript'>
  alert('Record deleted');
  window.location=('adminviewstud.php');
  </script>";
}



 ?>