<?php 
include "connect.php";
$bookid=$_GET['bookid'];
$query="DELETE from books where book_id='$bookid' ";
$result=mysqli_query($conn,$query);
if(!$result)
{
  echo "<script type='text/javascript'>
  alert('deletion failed');
  </script>";
}
else
{
  echo "<script type='text/javascript'>
  alert('Record deleted');
  window.location=('adminviewbooks.php');
  </script>";
}



 ?>