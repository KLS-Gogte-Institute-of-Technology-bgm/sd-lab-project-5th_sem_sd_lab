<?php
include "connect.php";
$staffid=$_GET['staffid'];
$bid=$_GET['bid'];
$q2="select qty from books where book_id='$bid' ";
$rs2=mysqli_query($conn,$q2);
while($row=mysqli_fetch_assoc($rs2))
{
	$qty=$row['qty'];
	$total=$qty+1;


}
//echo $total;
$q3="UPDATE books set qty='$total' where book_id='$bid'";
$rs3=mysqli_query($conn,$q3);
if(!$rs3)
{
	echo "<script type='text/javscript'>
	alert('Updation Failed');
	window.location='adminissue.php';
	</script> ";
}
else
{
	echo "<script type='text/javscript'>
	alert('Updated ');
	window.location='adminissue.php';
	</script> ";
}



$query="DELETE from staffbarrow where staff_id='$staffid' and book_id='$bid' ";
$result=mysqli_query($conn,$query);
if(!$result)
{
	echo "<script type='text/javscript'>
	alert('Deletion Failed');
	window.location='adminissue.php';
	</script> ";
}
else
{
	echo "<script type='text/javscript'>
	alert('Deleted ');
	window.location='adminissue.php';
	</script> ";
}



?>