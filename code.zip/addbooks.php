<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        padding:10px;
       
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        padding: 10px;
        
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>         
                      <li><a href="addstaff.php">Register Staff</a></li>
                      <li><a href="addstud.php">Register Student</a></li>
                      <li><a href="addbooks.php">Add Books</a></li>
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
    <center>
      <h1 style="color:black;">Add Books</h1>
      <form method="post" action="">
        <table>
          <tr>
            <th>Enter Book ID</th>
            <td><input style="border-radius:15px;" type="text" name="b_id"></td>
          </tr>
           <tr>
            <th>Book Title</th>
            <td><input style="border-radius:15px;" type="text" name="bname" pattern="^[A-Za-z]+$"></td>
          </tr>
           <tr>
            <th> Author</th>
            <td><input style="border-radius:15px;" type="text" name="author" pattern="^[A-Za-z]+$"></td>
          </tr>
           <tr>
            <th> Publication</th>
            <td><input style="border-radius:15px;" type="text" name="publication"></td>
          </tr>
           <tr>
            <th> Department</th>
            <td><input style="border-radius:15px;" type="text" name="dept"></td>
          </tr>
           
           <tr>
            <th> Quantity</th>
            <td><input style="border-radius:15px;" type="text" name="qty"></td>
          </tr>
        </table>
        <br>
        <input style=" background-color: #0000FF; width: 150px;height: 40px; border-radius:30px; color:white;" type="submit" name="submit" value="Register">
      </form>
    </center>
    </div>

    <?php 
      include "connect.php";
      if(isset($_POST['submit']))
      {
        $b_id=$_POST['b_id'];
        $bname=$_POST['bname'];
        $author=$_POST['author'];
        $publication=$_POST['publication'];
        $dept=$_POST['dept'];       
        $qty=$_POST['qty'];

        $query="insert into books values('$b_id','$bname','$author','$publication','$dept','$qty')";
        $result=mysqli_query($conn,$query);
        if(!$result)
        {
          die('error'.mysqli_error('$conn') );
          echo "<script type='text/javascript'>
          alert('Insertion Failed');
          </script>";
        }
        else
        {
          echo "<script type='text/javascript'>
         window.location=('addbooks.php');
          </script>";
        }

      }


     ?>
</body>
</html>