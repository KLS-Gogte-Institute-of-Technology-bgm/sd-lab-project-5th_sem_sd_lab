<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    
    
       td   
       {
        
       padding: 20px;
       font-size: 18px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       
       }
       th
       {
        text-align: center;
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>          
                      <li><a href="adminviewstaff.php">View Staff</a></li>
                      <li><a href="adminviewstud.php"> View Student</a></li>
                      
                       <li><a href="adminviewbooks.php">View Books</a></li>
                       
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
    
    <?php 
      $usn=$_GET['usn'];
      include "connect.php";
      $q1="SELECT * from student where USN='$usn' ";
      $rs1=mysqli_query($conn,$q1);
      while($row=mysqli_fetch_assoc($rs1))
      {?>
        <center>
          <h1 style="color:black;"> Modify Student details</h1>
          <form method="post" action="">
        <table>
          <tr>
            <td>USN</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="usn" value="<?php echo $row['USN']; ?>" readonly></td>
          </tr>
          <tr>
            <td>Name</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="sname" value="<?php echo $row['name']; ?>" ></td>
          </tr>
           <tr>
            <td>Address</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="saddr" value="<?php echo $row['address']; ?>" ></td>
          </tr>
          <tr>
            <td>Contact</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="scont" value="<?php echo $row['contact']; ?>" ></td>
          </tr>
          <tr>
            <td>Department</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="dept" value="<?php echo $row['dept']; ?>" ></td>
          </tr>
          <td>Semester</td>
            <td><input style="width: 200px; height: 40px; border-radius: 10px;" type="text" name="sem" value="<?php echo $row['sem']; ?>" ></td>
          </tr>
          

        </table>
        <input style=" background:blue; color:white; width: 200px; height: 40px; border-radius: 30px;" type="submit" name="submit" value="Update" >
        </form>
        </center>

      <?php }

     ?>

    </div>
    <?php 
      if(isset($_POST['submit']))
      {
        $usn=$_POST['usn'];
        $sname=$_POST['sname'];
        $saddr=$_POST['saddr'];
        $scont=$_POST['scont'];
        $dept=$_POST['dept'];
        $sem=$_POST['sem'];

        $update="UPDATE student set name='$sname',address='$saddr', contact='$scont', dept='$dept', sem='$sem' where USN='$usn' ";
        $result=mysqli_query($conn,$update);
        if(!$result)
        {
          echo "<script type='text/javascript'>
          alert('Updation Failed');
          </script>";
          die('error'.mysqli_error($conn));
        }
        else
        {
         echo "<script type='text/javascript'>
          alert('Updation Successful');
          window.location=('adminviewstud.php');
          </script>"; 
        }
      }


     ?>
</body>
</html>