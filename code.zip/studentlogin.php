<?php 


  session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        
        text-align: center;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        text-align: center;
       }

   </style>
  </head>
  <body>	
	<header id="header">
       1
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.html">Home</a></li>
                        
                        <li><a href="adminlogin.php">Admin</a></li>
                        <li><a href="stafflogin.php">Staff</a></li><li><a href="studentlogin.php">Student</a></li>
                                              
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <center>
        <form method="post" action="">

            <table>

                <h2>Student Login</h2>
                <tr>
                    <th>USN</th>
                    <td><input style="border-radius: 10px;"  type="text" name="usn"></td>
                </tr>
                <tr>
                    <th>Password</th>
                    <td><input style="border-radius: 10px;"  type="password" name="pass"></td>
                </tr>
                
            </table>
            <input style="width:200px;height: 50px; color:white; border-radius: 40px; text-align: center; background-color: #0000FF;"  type="submit" name="submit">
        </form>
    </center>

     <?php 

    include "connect.php";
    if(isset($_POST['submit']))
    {
        $usn=$_POST['usn'];
        $pass=$_POST['pass'];

        $query="select * from student where usn='$usn' and password='$pass' ";
        $result=mysqli_query($conn,$query);
        $data=mysqli_fetch_assoc($result);
        if(!$data)
        {
            die('error' .mysqli_error($conn));
            echo "<script type='text/javascript'>
            alert('Invalid Username/Password');
            </script>";
        }
        else
        {   
            $_SESSION['usn']=$usn;
            echo "<script type='text/javascript'>
            
            window.location=('studentindex.php');
            </script>";
        }
    }

 ?>



</body>
</html>