<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        height: 200px;
        width: 400px;
    }
    
       td   
       {
        
        text-align: center;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        text-align: center;
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>          
                      <li><a href="adminissuestaff.php">Issue Staff</a></li>
                      <li><a href="adminissuestud.php"> Issue Student</a></li>
                      
                       <li><a href="adminviewissuestaff.php">View Issue Staff</a></li>
                        <li><a href="adminviewissuestud.php">View Issue Student</a></li>
                       
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
     <div id="middle">
    <center>
      <h1 style="color:black;">Staff Issue Form</h1>
      <form method="post" action="">
        <table>
          <tr>
            <th>Enter Staff_id</th>
            <td><input style="border-radius:15px;" type="text" name="staffid"></td>
          </tr>             
           
          <tr>
            <th>Enter Book ID</th>
            <td><input style="border-radius:15px;" type="text" name="b_id"></td>
          </tr>

         <tr>
           <th>Enter Issue Date</th>
           <td><input style="border-radius:15px;" type="date" name="issuedate"></td>
         </tr>

         <tr>
           <th>Enter Return Date</th>
           <td><input style="border-radius:15px;" type="date" name="returndate"></td>
         </tr>
          
        </table>
        <br>
        <input style=" background-color: #0000FF; width: 150px;height: 40px; border-radius:30px; color:white;" type="submit" name="submit" value="Register">
      </form>
    </center>
    </div>
    <?php 
      include "connect.php";
      if(isset($_POST['submit']))
      {
        $staffid=$_POST['staffid'];        
        $b_id=$_POST['b_id'];
        $issuedate=$_POST['issuedate'];
        $returndate=$_POST['returndate'];

        $query="select * from staff,books where staff_id='$staffid' and book_id='$b_id'";
        $result=mysqli_query($conn,$query);
        while($row=mysqli_fetch_assoc($result))
        {
          $name=$row['name'];
          $dept=$row['dept'];         
          $book_title=$row['book_title'];
          $author=$row['author'];
          $publication=$row['publication']; 
          $qty=$row['qty'];  
          $totalqty=$qty-1;  

        }
        $q1="insert into staffbarrow values('$staffid','$name','$dept','$b_id','book_title','$author','$publication','$issuedate','$returndate') ";
        $rs1=mysqli_query($conn,$q1);

        if(!$rs1)
        {
          die('error'.mysqli_error($conn));
          echo "<script type='text/javascript'>
          alert('Insertion Failed');
          </script>";
        }
        else
        {
           echo "<script type='text/javascript'>
         
          window.location=('adminissuestaff.php');
          </script>";
        }

        $q2="update books set qty ='$totalqty' where book_id='$b_id' ";
        $rs2=mysqli_query($conn,$q2);
        if(!$rs2)
        {
          echo "<script type='text/javascript'>
          alert('Updation Failed');
          </script>";
          die('error'.mysqli_error($conn));
          
        }
        else
        {
          
          echo "<script type='text/javascript'>
          alert('Updated');
          </script>";
        }
        
        
        
       

      }


     ?>


</body>
</html>