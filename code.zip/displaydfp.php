<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		td	
		{
			padding: 20px;
		}

	</style>
</head>
<body>
	<center>
		<table>
			<tr>
				<th>Department</th>
				<th>Semester</th>
				<th>Subject</th>
				<th>Year</th>
				<th>Question Paper</th>
			</tr>
		
<?php
	include "connect.php";
	$q1="select * from questionpaper";
	$rs1=mysqli_query($conn,$q1);
	while($row=mysqli_fetch_assoc($rs1))
	{?>
<tr>
		<td><?php echo $row['dept'] ?></td>
		<td><?php echo $row['sem'] ?></td>
		<td><?php echo $row['subject'] ?></td>
		<td><?php echo $row['examyear'] ?></td>
		<td><?php echo $row['qp'] ?></td>
		<td><input type="button" value="Download" onclick="window.location='pdf.php?qp=<?php echo $row['qp']; ?>'"></td>
</tr>
<?php } 

?>
</table>
	</center>

</body>
</html>







