<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    
    
       td   
       {
        
       padding: 20px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        padding:20px;
       }
       #middle
       {
        margin-top:120px;
       }
       .col1
       {
        background-color: orange;
       }
       .col2
       {
        background-color:green;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="adminindex.php">Home</a></li>          
                      <li><a href="adminissuestaff.php">Issue Staff</a></li>
                      <li><a href="adminissuestud.php"> Issue Student</a></li>
                      
                       <li><a href="adminviewissuestaff.php">View Issue Staff</a></li>
                        <li><a href="adminviewissuestud.php">View Issue Student</a></li>
                       
                      <li><a href="index.html">Logout</a></li>

                                               
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
    <div id="middle">
    <center>
        <h1 style="color:black;">Student Borrow Details</h1>
    <table >
      <tr>
      <th>USN</th>
      <th>Name</th>
      <th>Department</th>
      <th>Sem</th>
      <th>Book ID</th>
      <th>Book Title</th>
      <th>Author</th>
      <th>Publication</th>
      <th>Issue Date</th>
      <th>Return Date</th>
      
      </tr>
      <tr>
        <?php 

        include "connect.php";
        $q1="select * from studborrow";
        $rs1=mysqli_query($conn,$q1);
        while($row=mysqli_fetch_assoc($rs1))
        {
          ?>
          <td><?php echo $row['usn']; ?></td>
          <td><?php echo $row['name']; ?></td>
          <td><?php echo $row['dept']; ?></td>   
          <td><?php echo $row['sem']; ?></td>          
          <td><?php echo $row['book_id']; ?></td>
          <td><?php echo $row['book_title']; ?></td>
          <td><?php echo $row['author']; ?></td>          
          <td><?php echo $row['publication']; ?></td>
          <td><?php echo $row['issue_date']; ?></td>
          <td><?php echo $row['return_date']; ?></td>
          
          
          <td><input style="width: 100px; height: 30px;" type="button" value="Return" onclick="window.location='deletestudissue.php?usn=<?php echo $row['usn']; ?>&bid=<?php echo $row['book_id']; ?> '"></td>

       <?php }


         ?>
      </tr>
      
    </table>
    </center>
    </div>
</body>
</html>