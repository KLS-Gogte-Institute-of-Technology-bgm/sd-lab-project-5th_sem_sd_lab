<?php 
  session_start();
  $usn=$_SESSION['usn'];
 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    
    
       td   
       {
        
        text-align: center;
        padding: 20px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        text-align: center;
        padding: 20px;
       }
       .format
       {
        margin-top: 200px;
        font-size: 20px;
       }

   </style>
  </head>
<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="studentindex.php">Home</a></li>               
                        <li><a href="studentprofile.php">Profile</a></li>
                        <li><a href="studviewbooks.php">View Books</a></li>
                        <li><a href="studviewissue.php">View Borrow Books</a></li>
                        <li><a href="studentviewqp.php">View Question Papers</a></li>
                        <li><a href="index.html">Logout</a></li>
                                             
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
<body>
	 <div class="format">
	<center>
		<table>
			<tr>
				<th>Department</th>
				<th>Semester</th>
				<th>Subject</th>
				<th>Year</th>
				<th>Question Paper</th>
			</tr>
		
<?php
	include "connect.php";
	$q1="select * from questionpaper";
	$rs1=mysqli_query($conn,$q1);
	while($row=mysqli_fetch_assoc($rs1))
	{?>
<tr>
		<td><?php echo $row['dept'] ?></td>
		<td><?php echo $row['sem'] ?></td>
		<td><?php echo $row['subject'] ?></td>
		<td><?php echo $row['examyear'] ?></td>
		<td><?php echo $row['qp'] ?></td>
		<td><input type="button" value="Download" onclick="window.location='pdf.php?qp=<?php echo $row['qp']; ?>'"></td>
</tr>
<?php } 

?>
</table>
	</center>
</div>

</body>
</html>







