<?php 
  session_start();
  $staffid=$_SESSION['staffid'];
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
   
   <style type="text/css">
    h2
    {
        margin-top: 150px;
        font-size: 30px;
    }
    table
    {
       
        
    }
    
       td   
       {
        
        padding: 20px;
       }
      tr td input
       {
        width: 200px;
        height: 40px;
       border-radius: 20px;
       }
       th
       {
        padding: 20px;
        text-align: center;
       }
       #middle
       {
        margin-top:120px;
        font-size: 20px;
       }

   </style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-left">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="staffindex.php">Home</a></li>               
                        <li><a href="staffprofile.php">Profile</a></li>
                        <li><a href="staffviewbooks.php">View Books</a></li>
                         <li><a href="staffviewissue.php">View Books Borrowed</a></li>
                        <li><a href="index.html">Logout</a></li>
                                             
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header>
     <div id="middle">
      <center>
        <table>
        <h1 style="color:black;">Staff Profile</h1>
        <br><br>
        
        <?php 
          include "connect.php";
          $q1="select * from staff where staff_id='$staffid'  ";
          $rs=mysqli_query($conn,$q1);
          while($row1=mysqli_fetch_assoc($rs))
          {?>

            <tr>
            
            <center><img src="<?php echo $row1['photo']; ?>" height="100px" width="100px"></center>
            </tr>

            <tr>
            <td>USN</td>
            <td><?php echo $row1['staff_id']; ?></td>
            </tr>

            <tr>
            <td>Name:</td>
            <td><?php echo $row1['name']; ?></td>
            </tr>

            <tr>
            <td>Address</td>
            <td><?php echo $row1['address']; ?></td>
            </tr>

            <tr>
            <td>Contact</td>
            <td><?php echo $row1['contact']; ?></td>
            </tr>

            <tr>
            <td>Department</td>
            <td><?php echo $row1['dept']; ?></td>
            </tr>

            


          <?php } ?>


         
      </table>
      </center>
     </div>


</body>
</html>