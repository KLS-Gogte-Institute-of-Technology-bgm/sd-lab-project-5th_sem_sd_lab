<?php
include "connect.php";
$usn=$_GET['usn'];
$bid=$_GET['bid'];
$q2="select qty from books where book_id='$bid' ";
$rs2=mysqli_query($conn,$q2);
while($row=mysqli_fetch_assoc($rs2))
{
	$qty=$row['qty'];
	$total=$qty+1;


}
echo $total;
$q3="UPDATE books set qty='$total' where book_id='$bid'";
$rs3=mysqli_query($conn,$q3);
if(!$rs3)
{
	echo "<script type='text/javscript'>
	alert('Updation Failed');
	</script> ";
}
else
{
	echo "<script type='text/javscript'>
	alert('Updated ');
	window.location=('adminviewissuestud.php');
	</script> ";
}



$query="DELETE from studborrow where usn='$usn' and book_id='$bid' ";
$result=mysqli_query($conn,$query);
if(!$result)
{
	echo "<script type='text/javscript'>
	alert('Deletion Failed');
	</script> ";
}
else
{
	echo "<script type='text/javscript'>
	alert('Deleted ');
	window.location=('adminviewissuestud.php');
	</script> ";
}



?>